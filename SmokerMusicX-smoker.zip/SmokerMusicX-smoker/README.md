# SMOKER MUSICX

### Best Smart Voice Chat Music Bot For Telegram Groups ...


<p align="center"><a href="https://t.me/sanki_owner"><img src="https://te.legra.ph/file/cb120c72f464ff25025a3.jpg"></a></p>


# ʜᴇʀoᴋᴜ ᴅᴇᴘʟᴏʏ
<p align="center"><a href="https://heroku.com/deploy?template=https://github.com/EsportMusicX/SmokerMusicX"> <img src="https://img.shields.io/badge/Deploy%20To%20Heroku-grey?style=for-the-badge&logo=heroku" width="220" height="38.45"/></a></p>

## ᴅᴇᴘʟᴏʏ ʀᴀɪʟᴡᴀʏ ꜱᴇʀᴠᴇʀ </h4>

[![Deploy+To+Railway](https://railway.app/button.svg)](https://railway.app/new/template?template=https://github.com/EsportMusicX/SmokerMusicX&envs=SESSION_NAME,BOT_TOKEN,BOT_NAME,API_ID,API_HASH,SUDO_USERS,DURATION_LIMIT)


ꜱᴛʀɪɴɢ ɴᴀᴍᴇ:

[![GenerateString](https://img.shields.io/badge/repl.it-generateString-brown)](https://replit.com/@HEXOROP/eSportMusic)



